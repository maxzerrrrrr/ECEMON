#ifndef MENU_H
#define MENU_H

#include <allegro.h>
#include "menu.hpp"
#include "duel.hpp"
#include "shop.hpp"

int menu(int* choix, BITMAP *buffermenu, BITMAP* mythologia, BITMAP* cursor, BITMAP* play, BITMAP* wallpaper, BITMAP* slogan);
#endif // MENU_H
