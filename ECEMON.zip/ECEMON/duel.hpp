#ifndef DUEL_H
#define DUEL_H

#include <allegro.h>

void Duel(int *choix,BITMAP* buffermenu, BITMAP* cases_terrain, BITMAP* cursor, BITMAP* terrain, BITMAP* cadre, BITMAP* cadre_b, BITMAP* buffer,  BITMAP* terrain_b, BITMAP* cases_terrain_b, BITMAP* carte_m);
#endif // DUEL_H
