#include "Sort.h"

Sort::Sort()
{
    //ctor
}

Sort::~Sort()
{
    //dtor
}
