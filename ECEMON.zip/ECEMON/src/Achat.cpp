#include "Achat.h"

Achat::Achat()
{
    //ctor
}

Achat::~Achat()
{
    //dtor
}


