#ifndef SORT_H
#define SORT_H

#include "Carte.h"
#include <allegro.h>

class Sort : public Carte
{
public:
    Sort();
    virtual ~Sort();

protected:

private:
};

#endif // SORT_H
